package org.iot.raspberry.pi.devices;

/**
 *
 * @author Eduardo Moranchel <emoranchel@asmatron.org>
 */
public class RaspiLed {

}
