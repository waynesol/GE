package org.iot.raspberry.grovepi;

public @interface GroveDigitalPin {

}
